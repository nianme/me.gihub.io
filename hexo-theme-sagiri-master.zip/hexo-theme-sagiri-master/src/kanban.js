if (!NexT.utils.isMobile()) {
  require('./live2d');

  loadlive2d("live2d", "/images/live2d/22/22.model.json");
}
