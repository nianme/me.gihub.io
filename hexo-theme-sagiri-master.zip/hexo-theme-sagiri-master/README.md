<h1 align="center">Sagiri</h1>

> As lovely as sagiri

[![npm](https://img.shields.io/npm/v/hexo-theme-sagiri.svg?style=flat-square)](https://www.npmjs.com/package/hexo-theme-sagiri)
[![npm](https://img.shields.io/npm/l/hexo-theme-sagiri.svg?style=flat-square)](https://github.com/DIYgod/hexo-theme-sagiri/blob/master/LICENSE)
[![npm](https://img.shields.io/npm/dt/hexo-theme-sagiri.svg?style=flat-square)](https://www.npmjs.com/package/hexo-theme-sagiri)
[![dependency Status](https://img.shields.io/david/DIYgod/hexo-theme-sagiri.svg?style=flat-square)](https://david-dm.org/DIYgod/hexo-theme-sagiri)
[![devDependency Status](https://img.shields.io/david/dev/DIYgod/hexo-theme-sagiri.svg?style=flat-square)](https://david-dm.org/DIYgod/hexo-theme-sagiri#info=devDependencies)
[![donate](https://img.shields.io/badge/$-donate-ff69b4.svg?style=flat-square)](https://github.com/DIYgod/hexo-theme-sagiri#donate)

## Introduction

Lovely theme for Hexo.

As lovely as sagiri, based on [hexo-theme-next](https://github.com/iissnan/hexo-theme-next)

## Who use hexo-theme-sagiri?

## Donate

- [Donate via Paypal](https://www.paypal.me/DIYgod)
- [Donate via WeChat Pay](https://ws4.sinaimg.cn/large/006tKfTcgy1fhu1uowywej307s07st8h.jpg)
- [Donate via Alipay](https://ws4.sinaimg.cn/large/006tKfTcgy1fhu1vf4ih7j307s07sdfm.jpg)
- Donate via Bitcoin: 13CwQLHzPYm2tewNMSJBeArbbRM5NSmCD1

## Author

**hexo-theme-sagiri** © [DIYgod](https://github.com/DIYgod), Released under the [MIT](./LICENSE) License.<br>
Authored and maintained by DIYgod with help from contributors ([list](https://github.com/DIYgod/hexo-theme-sagiri/contributors)).

> Blog [@Anotherhome](https://www.anotherhome.net) · GitHub [@DIYgod](https://github.com/DIYgod) · Twitter [@DIYgod](https://twitter.com/DIYgod) · Telegram Channel [@awesomeDIYgod](https://t.me/awesomeDIYgod)
